def telegram_bot_id():
    return 'You TG bot'

def telegram_сhat_id():
    return int() #You Telegram_id

def token_tinkoff_invest():
    return 'access_token (tinkoff invest)'
