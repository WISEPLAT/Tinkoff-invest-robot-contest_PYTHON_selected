class DecisionExecutionError(Exception):
    pass


class ConfigError(Exception):
    pass
