#!/bin/bash
docker pause tbot