#!/bin/bash
docker build -t tbot .
