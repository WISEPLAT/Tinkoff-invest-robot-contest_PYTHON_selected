#!/bin/bash
docker run --rm -it -v $(pwd):/app tbot