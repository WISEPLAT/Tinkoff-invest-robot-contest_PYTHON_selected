#!/bin/bash
docker stop tbot