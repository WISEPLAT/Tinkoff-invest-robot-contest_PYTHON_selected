#!/bin/bash
docker logs tbot