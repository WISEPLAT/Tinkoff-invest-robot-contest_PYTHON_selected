#!/bin/bash
docker run --rm -d --name tbot -it -v $(pwd):/app tbot