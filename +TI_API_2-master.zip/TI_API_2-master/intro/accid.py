ACC_ID = "Your_ID"
# Получить можно используя GetAccount в Account_n_Portfolio.py
