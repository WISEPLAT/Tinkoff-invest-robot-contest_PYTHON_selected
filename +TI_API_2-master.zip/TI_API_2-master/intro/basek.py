TINKOFF_INVEST_DOG_NEW = "Your_Token"
# Как получить: https://tinkoff.github.io/investAPI/token/
