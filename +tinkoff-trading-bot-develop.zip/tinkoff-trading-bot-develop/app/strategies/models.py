from enum import Enum


class StrategyName(Enum):
    INTERVAL = "interval"
